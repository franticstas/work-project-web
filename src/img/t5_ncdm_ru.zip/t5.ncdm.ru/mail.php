<?php
/**
 * Created by PhpStorm.
 * User: Николай
 * Date: 07.08.2017
 * Time: 15:43
 */



print_r($_POST);

mail("ily.fomin@mail.ru","","sadasd");


?>